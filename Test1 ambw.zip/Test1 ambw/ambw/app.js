const container = document.getElementById('posts-container');

function loadPosts() {
 
  const posts = [
    {
      id: 1,
      title: 'PWA MATERI',
      body: 'PWA INI SEMSETER ^ DI UKP UNTUK MEMPELAJARI!'
    },
    {
      id: 2,
      title: 'PWA fetch dan offline',
      body: 'PWA Materi memeilikki fetch dan offline.'
    },
    {
      id: 3,
      title: 'CARA melakukan pwa',
      body: 'mengikuti langkah2'
    }
  ];

  container.innerHTML = '';


  posts.forEach(post => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <h2>${post.title}</h2>
      <p>${post.body}</p>
      <small>Post ID: ${post.id}</small>
    `;
    container.appendChild(card);
  });
}

loadPosts();
