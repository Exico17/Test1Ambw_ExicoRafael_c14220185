document.addEventListener('DOMContentLoaded', async () => {
    const container = document.getElementById('posts-container');

    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/posts');
        const posts = await response.json();

        container.innerHTML = posts.slice(0, 10).map(post => `
            <article class="post-card">
                <h2>${post.title}</h2>
                <p>${post.body}</p>
                <small>Post ID: ${post.id}</small>
            </article>
        `).join('');
    } catch (error) {
        container.innerHTML = '<p>Failed to load posts. Please try again later.</p>';
    }
});
